import styled from 'styled-components'

// Eksempel på en styled component
export const MainHeading = styled.h1`
  font-size: 3.3rem;
  font-weight: 900;
`
