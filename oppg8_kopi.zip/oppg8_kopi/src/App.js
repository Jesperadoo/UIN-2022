import PageRoutes from './routes/Routes'

export default function App() {
  return <PageRoutes />
}
