import { useEffect, useState } from 'react'
import { getMovieByActor, getMovies } from '../lib/services/movieService'

const skuespiller = ['Chris Evans', 'React']

export default function Movie() {
  const [movie, setMovie] = useState(false)
  const [content, setContent] = useState([])

  useEffect(() => {
    const getMovieData = async () => {
      setMovie(true)
      const movies = await getMovies()

      setContent(movies)
      setMovie(false)
    }
    getMovieData()
  }, [])

  const handleFilter = async (event) => {
    const actor = event.target.value.toLowerCase()
    let data
    if (actor === 'alle') {
      data = await getMovies()
    } else {
      data = await getMovieByActor(actor)
    }
    setContent(data)
  }

  return (
    <div>
      <select
        id="actor"
        defaultValue="Alle"
        className="m-auto mb-5 flex w-52 rounded-md border-gray-300 py-2 pl-3 pr-8 text-base focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
        onChange={handleFilter}
      >
        <option value="Alle">Alle</option>
        {skuespiller.map((actor) => (
          <option key={actor} value={actor}>
            {actor}
          </option>
        ))}
      </select>
      <div className="mb-52 grid grid-cols-3 gap-5 text-2xl">
        {content?.map((film) => (
          <div className="rounded-lg bg-yellow-100 p-5 text-stone-700 shadow-lg">
            <h1 key={film.slug} className="flex justify-center">
              {film.title}
            </h1>
            <img
              src={film.poster?.asset.url}
              alt="img"
              className="m-auto mt-4 flex max-h-40 rounded-lg"
            />
          </div>
        ))}
      </div>
    </div>
  )
}
