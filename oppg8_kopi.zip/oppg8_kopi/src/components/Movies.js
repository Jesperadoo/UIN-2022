import Movie from './Movie'

export default function Movies() {
  return (
    <main>
      <Movie />
    </main>
  )
}
