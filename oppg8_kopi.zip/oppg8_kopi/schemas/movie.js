export default {
  type: 'document',
  name: 'movie',
  title: 'Film',
  fields: [
    {
      type: 'string',
      name: 'title',
      title: 'Tittel',
      description: 'Fyll inn filmtittel',
    },
    {
      type: 'image',
      name: 'poster',
      title: 'Plakat',
      description: 'Legg inn plakatbilde',
    },
    {
      type: 'array',
      name: 'actor',
      title: 'Skuespiller',
      description: 'Hent skuespillere',
      of: [
        {
          type: 'reference',
          to: [
            {
              type: 'actor'
            },
          ]
        },
      ],
    },
  ],
}